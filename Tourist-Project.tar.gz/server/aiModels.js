const aiModels = {
  trips: "gemini",
  reasoning: "o3-mini",
  chatbot: "gpt-4-turbo",
};

module.exports = aiModels;
